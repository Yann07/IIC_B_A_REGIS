

<!-- page d'accueuil redirige directement vers les services pour la démo -->

<?php

header('Location: services.php');